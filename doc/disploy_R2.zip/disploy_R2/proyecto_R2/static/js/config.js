
function showResult(id, message) {
    const resultDiv = document.getElementById(id);
    resultDiv.style.display = 'block';
    resultDiv.style.opacity = '0';
    setTimeout(() => { resultDiv.style.opacity = '1'; }, 50);
    resultDiv.innerText = message;
}

async function handleForm(formId, resultId, url, getData, formatResult) {
    const form = document.getElementById(formId);
    form.onsubmit = async function(e) {
        e.preventDefault();
        const data = getData();
        try {
            const res = await fetch(url, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(data)
            });
            if (!res.ok) throw new Error('Error en la respuesta del servidor');
            const result = await res.json();
            showResult(resultId, formatResult(result));
        } catch(err) {
            showResult(resultId, "❌ Error al predecir: " + err.message);
        }
    };
}

// Mensajes y recomendaciones
function getImpactScoreMessage(score) {
    if(score < 2) 
        return `Impact Score: ${score.toFixed(2)} (Bajo)\n🔸 Recomendación: Juega más defensivamente y mejora tu puntería.`;
    if(score <= 5) 
        return `Impact Score: ${score.toFixed(2)} (Medio)\n🔸 Recomendación: Coordina con tu equipo para mejorar el desempeño.`;
    return `Impact Score: ${score.toFixed(2)} (Alto)\n🔸 Recomendación: Excelente rendimiento, prueba estrategias avanzadas.`;
}

function getHasWonMessage(haswon) {
    return haswon ? "¡Ganaste la ronda!\n🔸 Recomendación: Mantén tu estrategia y buen uso de operadores." 
                  : "No ganaste esta vez.\n🔸 Recomendación: Mejora posicionamiento y comunicación con tu equipo.";
}

// Formularios separados
handleForm('regresionForm', 'result_regresion', '/predict/regresion', () => ({
    gamemode: parseInt(document.getElementById('gamemode').value),
    winrole: parseInt(document.getElementById('winrole').value),
    endroundreason: parseInt(document.getElementById('endroundreason').value),
    roundduration: parseFloat(document.getElementById('roundduration').value),
    isdead: parseInt(document.getElementById('isdead').value),
    nbkills: parseInt(document.getElementById('nbkills').value)
}), (result) => getImpactScoreMessage(result.impact_score));

handleForm('clasificacionForm', 'result_clasificacion', '/predict/clasificacion', () => ({
    primaryweapon: parseInt(document.getElementById('primaryweapon').value),
    mapname: parseInt(document.getElementById('mapname').value),
    gamemode: parseInt(document.getElementById('gamemode_c').value),
    winrole: parseInt(document.getElementById('winrole_c').value),
    roundduration: parseFloat(document.getElementById('roundduration_c').value),
    nbkills: parseInt(document.getElementById('nbkills_c').value),
    isdead: parseInt(document.getElementById('isdead_c').value)
}), (result) => getHasWonMessage(result.haswon));


