from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, conint
from pathlib import Path
import joblib
import pandas as pd

# --- Configuración básica ---
app = FastAPI(title="Simulador CSGO")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# --- Endpoints ---
@app.get("/", response_class=HTMLResponse)
async def read_index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# --- Carga de modelos con rutas absolutas ---
BASE_DIR = Path(__file__).resolve().parent
ruta_modelo_regresion = BASE_DIR / "models" / "modelo_regresion.pkl"
ruta_modelo_clasificacion = BASE_DIR / "models" / "modelo_clasificacion.pkl"

try:
    modelo_regresion = joblib.load(ruta_modelo_regresion)
except FileNotFoundError:
    modelo_regresion = None
    print("⚠️ Modelo de regresión no encontrado.")

try:
    modelo_clasificacion = joblib.load(ruta_modelo_clasificacion)
except FileNotFoundError:
    modelo_clasificacion = None
    print("⚠️ Modelo de clasificación no encontrado.")

# --- Esquemas Pydantic ---
class InputRegresion(BaseModel):
    gamemode: int
    winrole: int
    endroundreason: int
    roundduration: float
    isdead: conint(ge=0, le=1)
    nbkills: int

class InputClasificacion(BaseModel):
    primaryweapon: int
    mapname: int
    gamemode: int
    winrole: int
    roundduration: float
    nbkills: int
    isdead: conint(ge=0, le=1)

# --- Endpoints de predicción ---
@app.post("/predict/regresion")
def predict_regresion(data: InputRegresion):
    if modelo_regresion is None:
        raise HTTPException(status_code=500, detail="Modelo de regresión no disponible.")

    try:
        entrada = pd.DataFrame([[
            data.gamemode,
            data.winrole,
            data.endroundreason,
            data.roundduration,
            data.isdead,
            data.nbkills
        ]], columns=[
            'gamemode',
            'winrole',
            'endroundreason',
            'roundduration',
            'isdead',
            'nbkills'
        ])
        prediccion = modelo_regresion.predict(entrada)
        return {"impact_score": float(prediccion[0])}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error en predicción de regresión: {str(e)}")

@app.post("/predict/clasificacion")
def predict_clasificacion(data: InputClasificacion):
    if modelo_clasificacion is None:
        raise HTTPException(status_code=500, detail="Modelo de clasificación no disponible.")

    try:
        entrada = pd.DataFrame([[
            data.primaryweapon,
            data.mapname,
            data.gamemode,
            data.winrole,
            data.roundduration,
            data.nbkills,
            data.isdead
        ]], columns=[
            'primaryweapon',
            'mapname',
            'gamemode',
            'winrole',
            'roundduration',
            'nbkills',
            'isdead'
        ])
        prediccion = modelo_clasificacion.predict(entrada)
        return {"haswon": int(prediccion[0])}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error en predicción de clasificación: {str(e)}")
